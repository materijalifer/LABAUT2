%% --------------------- 2. ZADATAK -----------------------------
close all
clear
clc
tmass_ss;
%% 2.a) varanje
[num, den] = ss2tf(A,B,C(1,:), D(1), 1);
Gideal = tf(num, den);
Gideal_info = stepinfo(Gideal, 'SettlingTimeTreshold', 0.05);
t95 = Gideal_info.SettlingTime;
%% izracun %%
wg=60;
Suu=0.0011;
dt=2.77/wg;
T=1.5*t95;
N=T/dt;
n=ceil(log2(N+1));
N=2^n-1;
dt=T/N;
w0=2*pi/(N*dt);
ni=round(wg/w0);
% velika formula %
syms x
c = solve(Suu == x^2*((N+1)/N^2)*(sin(ni*pi/N)/(ni*pi/N))^2, x);
c=double(abs(c(1)));
%%
Ts=dt;
Tsim=T*10;
dw=2*pi/Tsim;
%
prbs = idinput(255, 'PRBS', [0, 1], [-c, c]);
sim('tromaseni_model2')
%%
Z1=[data.signals.values(:,2),data.signals.values(:,1)];
Z2=[data.signals.values(:,3),data.signals.values(:,1)];

figure(1)
hold off;
IR1=cra(Z1,100);
IR2=cra(Z2,100);
plot (IR1,'b');
title('Estiated impulse responce')
hold on;
plot (IR2,'g');
legend('with noise','no noise')
grid on
%saveas(gcf,'Slike/2b estimacija.png')
%
figure(2)
hold off;
IR1=cra(Z1,250);
IR2=cra(Z2,250);
plot (IR1,'r');
title('Estimated impulse responce')
hold on;
plot (IR2,'g');
legend('with noise','no noise')
grid on
saveas(gcf,'Slike1/2b estimacija dugi.fig')
%
figure(3)
hold off;
%plot (IR1(1:250),'b');
plot (linspace(0, 0.04229*250,250), IR1(1:250)*25.3165,'r');
title('Impulse responce')
hold on;
%figure(4)
impulse(tf(num,den),'g')
legend('estimated','ideal')
xlim([0 T])
grid on
saveas(gcf,'Slike1/2b estimacija usporedba.fig')
% ulazni izlazni
figure(4)
hold off;
stairs(data.signals.values(1:250,1));
title('u')
hold on
grid on
saveas(gcf,'Slike1/2b ulazni signal.fig')
%
figure(5)
hold off;
plot(data.signals.values(1:250,2));
title('y')
hold on
grid on
saveas(gcf,'Slike1/2b izlazni signal.fig')

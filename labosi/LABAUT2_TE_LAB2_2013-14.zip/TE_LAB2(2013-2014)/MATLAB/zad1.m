close all
clear
clc
tmass_ss;
%% ----------------------- 1. ZADATAK -------------------------------------
%% 1.a)
%% pocetni parametri i simuliacija
chirpGain=1;
Ts=0.01;
dw=0.1;
Tsim=2*pi/dw;
sim('tromaseni_model');
%% chirp izvorni
figure(1)
title('Idealni izlaz')
plot(data.signals.values(:,3));
fftChirp=fft(data.signals.values(:,1));
figure(2);
subplot(2,1,1)
plot(abs(fftChirp));
title('izvorni')
subplot(2,1,2)
plot(angle(fftChirp));
%% chirp izrezani
cutL=2;%1000;%650;         %mijenjati
cutH=502;%length(fftChirp);%5200;%5630;        %mijenjati
cutFftChirp=fftChirp(cutL:cutH);
figure(3)
subplot(2,1,1)
plot(abs(cutFftChirp));
title('izrezani')
subplot(2,1,2)
plot(angle(cutFftChirp));
%% ChirpGain pa ponovno simuliranje s novim gainom kako bi avgAmp bio 188
avgAmp=sum(abs(cutFftChirp))/length(cutFftChirp)
chirpGain=188/avgAmp;
sim('tromaseni_model');
fftChirpGained=fft(data.signals.values(:,1));
cutFftChirpGained=fftChirpGained(cutL:cutH);
avgAmpGained=sum(abs(cutFftChirpGained))/length(cutFftChirpGained);
%% plot
close all
figure(1)
hold on
title('Chirp signal prije obrade')
plot(data.time, data.signals.values(:,1));
grid on
%saveas(gcf,'Slike/chirp prije obrade.png')
figure(2)
title('Izlazni signal prije obrade')
hold on
grid on
plot(data.time,data.signals.values(:,2), 'b')
plot(data.time,data.signals.values(:,3), 'g')
legend('sa �umom','bez �uma(idealni)')
%saveas(gcf,'Slike/izlazni signal prije obrade.png')
signal1NoOff=dtrend(data.signals.values(:,1));
signal2NoOff=dtrend(data.signals.values(:,2));
signal3NoOff=dtrend(data.signals.values(:,3));
% ----------------- obrada ----------------- %
figure(3)
hold on
title('Chirp signal nakon obrade')
plot(data.time, data.signals.values(:,1));
grid on
%saveas(gcf,'Slike/chirp nakon obrade.png')
figure(4)
title('Izlazni signal nakon obrade')
hold on
grid on
plot(data.time,signal2NoOff, 'b')
plot(data.time,signal3NoOff, 'g')
legend('sa �umom','bez �uma(idealni)')
%saveas(gcf,'Slike/izlazni signal nakon obrade.png')

%% 1.b)
close all
figure(1)
bode(tf(num,den))
grid on
%plot(xcorr(signal1NoOff, 100))
%%
W = linspace(0.01*2*pi, 8*2*pi, length(signal1NoOff));
figure(1)
hold off
H=1000;
G1=spektralnaAnaliza(signal2NoOff, signal1NoOff, H, W, 0.1);
bode(G1)
hold on
title('H=1000')
bode(tf(num,den))
grid on
legend('estimirani','idealni')
saveas(gcf,'Slike/bode1000.png')
%
figure(2)
hold off
H=500;
G2=spektralnaAnaliza(signal2NoOff, signal1NoOff, H, W, 0.1);
bode(G2)
hold on
title('H=500')
bode(tf(num,den))
grid on
legend('estimirani','idealni')
saveas(gcf,'Slike/bode500.png')
%
figure(3)
hold off
H=300;
G3=spektralnaAnaliza(signal2NoOff, signal1NoOff, H, W, 0.1);
bode(G3)
hold on
title('H=300')
bode(tf(num,den))
grid on
legend('estimirani','idealni')
%saveas(gcf,'Slike/bode300.png')
%% 1.c)
close all
figure(1)
subplot(2,1,1)
plot(abs(fft(signal2NoOff)));
title('Izlazni signal')
subplot(2,1,2)
plot(angle(fft(signal2NoOff)));
%saveas(gcf,'Slike/1c Izlazni signal.png')

figure(2)
subplot(2,1,1)
plot(abs(fft(signal1NoOff)));
title('Ulazni signal')
subplot(2,1,2)
plot(angle(fft(signal1NoOff)));
%saveas(gcf,'Slike/1c Ulazni siglnal.png')

G_jw=fft(signal2NoOff)./fft(signal1NoOff);
G_jw = idfrd(G_jw, linspace(0.01*2*pi,length(signal1NoOff)*dw,length(signal1NoOff)), Ts);
figure(3)
bode(G_jw)
hold on
grid on
bode(tf(num,den))
%saveas(gcf,'Slike/1cBode.png')
%% 1.d)e) - dalje dalje




